var searchData=
[
  ['ubicacion',['Ubicacion',['../class_ubicacion.html',1,'']]]
];

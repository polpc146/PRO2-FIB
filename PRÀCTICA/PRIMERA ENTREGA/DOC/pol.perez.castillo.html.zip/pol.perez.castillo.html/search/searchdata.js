var indexSectionsWithContent =
{
  0: "cdeghilmoprstu~",
  1: "cstu",
  2: "cpstu",
  3: "cdehilmoprstu~",
  4: "hp",
  5: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "typedefs",
  5: "Páginas"
};


var searchData=
[
  ['segmento',['Segmento',['../class_segmento.html',1,'']]]
];

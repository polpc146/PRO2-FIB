var searchData=
[
  ['donde',['donde',['../class_terminal.html#a2847cb58fe61bb488f089bc67a1973fe',1,'Terminal']]]
];

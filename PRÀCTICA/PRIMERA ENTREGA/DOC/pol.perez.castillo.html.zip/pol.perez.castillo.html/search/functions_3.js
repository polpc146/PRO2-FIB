var searchData=
[
  ['hilera',['hilera',['../class_ubicacion.html#abf00d08075e75ac833de7357ebc6f521',1,'Ubicacion']]],
  ['hileras',['hileras',['../class_terminal.html#a6e7268ad5b0ffbf1484f1f1522e800f0',1,'Terminal']]],
  ['hueco_5fmas_5fadecuado',['hueco_mas_adecuado',['../class_terminal.html#ab14183e499defc434f593c5767605834',1,'Terminal']]]
];

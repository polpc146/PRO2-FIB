var searchData=
[
  ['insertar_5fareadeespera',['insertar_AreaDeEspera',['../class_terminal.html#a7b12f84e1eeb3dacb6d73f6126bb13e1',1,'Terminal']]],
  ['insertar_5fcontenedor',['insertar_contenedor',['../class_terminal.html#a0448a45cc3dea91ab383c79246c9e50e',1,'Terminal']]]
];

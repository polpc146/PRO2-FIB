var searchData=
[
  ['y',['y',['../class_ubicacion.html#ab314f05b8da651aabb8a623467919a94',1,'Ubicacion']]]
];

var searchData=
[
  ['espera',['espera',['../class_terminal.html#ac9f71207d73c8d05a9d9d6c046f9f8c3',1,'Terminal']]]
];

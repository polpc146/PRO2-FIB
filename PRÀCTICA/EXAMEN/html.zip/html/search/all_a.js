var searchData=
[
  ['nuevo_5fhueco',['nuevo_hueco',['../class_almacenaje.html#ac98f7d262897f33ece29a432e111f02c',1,'Almacenaje']]],
  ['num_5fhileras',['num_hileras',['../class_terminal.html#a865c963b18aa837549dd637d439e8502',1,'Terminal']]],
  ['num_5fpisos',['num_pisos',['../class_terminal.html#ad6cdee7fe26b4443d45b0a18c345a86d',1,'Terminal']]],
  ['num_5fplazas',['num_plazas',['../class_terminal.html#a14265a71722ee28f3a50cee4a72e5607',1,'Terminal']]]
];

var searchData=
[
  ['actualizar_5fubicacion',['actualizar_ubicacion',['../class_almacenaje.html#a4035979df0e66a26d4b98d2b18d3d408',1,'Almacenaje']]],
  ['almacenaje',['Almacenaje',['../class_almacenaje.html#aac76140a19e358858ec775cae4d23037',1,'Almacenaje::Almacenaje()'],['../class_almacenaje.html#a647530e3470da788413fe0288eeca339',1,'Almacenaje::Almacenaje(int N, int M)']]]
];

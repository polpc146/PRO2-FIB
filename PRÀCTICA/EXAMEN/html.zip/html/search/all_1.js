var searchData=
[
  ['buscar_5fhuecos_5fi',['buscar_huecos_i',['../class_terminal.html#a204fc08e3b6f13f75c525f282b023b19',1,'Terminal']]],
  ['buscar_5fhuecos_5fr',['buscar_huecos_r',['../class_terminal.html#a56204987306ed811046d3ade11fff2cb',1,'Terminal']]]
];

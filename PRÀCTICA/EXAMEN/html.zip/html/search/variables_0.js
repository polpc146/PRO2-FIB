var searchData=
[
  ['almacenaje',['almacenaje',['../class_terminal.html#a1d87d7b16c4f460eee6f1ab73da90fd2',1,'Terminal']]],
  ['areadealmacenaje',['AreaDeAlmacenaje',['../class_terminal.html#a50670862a5cdeb0504efd1c45b6416dc',1,'Terminal']]],
  ['areadeespera',['AreaDeEspera',['../class_espera.html#adafca5e22c5bc21e517b363144fc6b18',1,'Espera']]]
];

#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::iterator it = l.end();
    Estudiant est;
    est.llegir();
    while (est.consultar_DNI() != 0 or est.consultar_nota() != 0) {
        l.insert(it, est);
        est.llegir();
    }
}

void EscriureLlistaEstudiant(const list<Estudiant>& l) {
    if (not l.empty()) {
        list<Estudiant>::const_iterator it;
        int i = 1;
        for (it=l.begin(); it!=l.end(); ++it) {
            Estudiant est = *it;
            cout << "Estudiante " << i << ":" << endl << "DNI -> " << est.consultar_DNI() << endl << "Nota -> " << est.consultar_nota() << endl;
            ++i;
        }
    }
    else cout << "No hay estudiantes" << endl;
}

#include "CuaIOParInt.hh"

using namespace std;

void llegirCuaParInt (queue<pair<int,int>>& c) {
    pair<int,int> par;
    bool sortir = false;
    while (not sortir and cin >> par.first >> par.second) {
        if (par.first==0 and par.second==0) sortir = true;
        else c.push(par);
    }
}

void escriureCuaParInt (queue<pair<int,int>>& c) {
    while (not c.empty()) {
        cout << c.front().first << " " << c.front().second << endl;
        c.pop();
    }
}
